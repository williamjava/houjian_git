package com.tu.redis;

public class Main {

	public static void main(String[] args) {
		new RedisClient().show();
	}

}
