package com.tu.test;

public class MyTest {

	public static void main(String[] args) {
		TestInterfaceImpl test = new TestInterfaceImpl();
		test.introduce();

	}

}
