package com.tu.test;
public @interface Authorities {
    Authority[] value();
}

